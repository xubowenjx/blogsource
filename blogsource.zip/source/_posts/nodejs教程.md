---
title: nodejs教程
date: 2017-06-30 21:29:09
tags:
    - nodejs
    - 前端
categories:
    - 技术
    - 前端
---
##  nodejs

### 配置环境
前往官网下载稳定版本,进行本地安装
安装完毕后执行
```bash
node -v
```
查看是否安装成功

### 使用nodejs
打开终端,进行基本一些`node`命令操作
```bash
node
1==1//true
```
也可以编写一个js文件再执行
//fun.js
```javascript
console.log("hellow world");
```
然后运行该文件
```bash
node fun.js
```




