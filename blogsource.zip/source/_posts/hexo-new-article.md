---
title: hexo-new-article
date: 2017-08-23 21:13:04
tags:
    - hexo
    - 前端
categories:
    - 技术
    - 前端
---
##  hexo新建文章

### 初始化md文件

```bash
hexo new file-name
```
然后就会提示你md文件的创建位置

### 文件结构
```md
---
title: 文章标题
date: 2017-06-30 21:29:09#创建时间
tags:#增加文章的标签
    - nodejs
    - 前端
categories:#增加文件的分类
    - 技术
    - 前端
---
下面标准的md文件的书写格式写文章就好
```





