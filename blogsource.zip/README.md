# blogsource
## how to use
* clone to your local
```bash
git clone  https://github.com/xubowenjx/blogsource.git
```
* install dependencies
```bash
npm install hexo-cli -g
npm install
```
* run local
```bash
hexo clean
hexo g
hexo s
```
* push to gitpage
```bash
hexo d -g
```
